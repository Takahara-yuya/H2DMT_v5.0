/*
***********************************************************************

MTmesh2D.h	(Constructing MT data)
This file is part of H2DMT.

***********************************************************************

Sep 01, 2023
Copyright 2023

Zuwei Huang
hzw1498218560@tongji.edu.cn
School of Ocean and Earth Science, Tongji University
Integrated Geophysics Group

Luolei Zhang
zhangluolei@hotmail.com
School of Ocean and Earth Science, Tongji University
Integrated Geophysics Group

version 5.0.0
Dec 04, 2024


***********************************************************************
*/

#include "../include/MTmesh2D.h"

void MTMesh2D::Init_MTMesh2D_File(string Filename, MTData2D data_obs)
{
	MTMesh2D::ReadMeshFile(Filename, data_obs);
	Num_Cen = Num_xCen * Num_yCen;
	Num_Node = Num_xNode * Num_yNode;
	//check the observation point , if not located at the center of the grid, exit!
}

void MTMesh2D::Init_MTMesh2D_Empty(int a, int b, std::vector<double> a1, std::vector<double> b1, double c)
{
	Num_xCen = a;
	Num_yCen = b;
	sinValue = c;
	Num_xNode = Num_xCen + 1;
	Num_yNode = Num_yCen + 1;

	Num_Cen = Num_xCen * Num_yCen;
	Num_Node = Num_xNode * Num_yNode;

	if (a1.size() != a + 1)
	{
		std::cerr << "Demension Misses!" << std::endl;
		exit(1);
	}
	if (b1.size() != b + 1)
	{
		std::cerr << "Demension Misses!" << std::endl;
		exit(1);
	}

	xNode.resize(Num_xNode);
	xNode.resize(Num_yNode);
	xCen.resize(Num_xCen);
	yCen.resize(Num_yCen);

	xNode.assign(a1.begin(), a1.end());
	yNode.assign(b1.begin(), b1.end());

	xmin = xNode.front(); xmax = xNode.back();
	ymin = yNode.front(); ymax = yNode.back();

	for (int i = 0; i < Num_xCen; i++)
	{
		xCen[i] = 0.5 * (xNode[i] + xNode[i + 1]);
	}

	for (int i = 0; i < Num_yCen; i++)
	{
		yCen[i] = 0.5 * (yNode[i] + yNode[i + 1]);
	}

	sgm1D.resize(Num_Cen);
	for (int ix = 0; ix < Num_xCen; ix++)
	{
		for (int iy = 0; iy < Num_yCen; iy++)
		{
			sgm1D(iy + ix * Num_yCen) = -c;
		}
	}

}

void MTMesh2D::ReadMeshFile(string Filename, MTData2D data_obs)
{
	double tmp; string tmpp;
	std::ifstream fin(Filename);
	if (!fin) {
		std::cerr << "Can't open MeshFile!\n";
		return;
	}
	fin >> tmpp;
	if (tmpp == "MARINE")marine = true;
	fin >> Num_xCen >> Num_yCen;

	Num_xNode = Num_xCen + 1;
	Num_yNode = Num_yCen + 1;
	Num_Cen = Num_xCen * Num_yCen;
	Num_Node = Num_xNode * Num_yNode;

	xNode.resize(Num_xNode);
	yNode.resize(Num_yNode);
	xCen.resize(Num_xCen);
	xTopo.resize(Num_xCen);
	yCen.resize(Num_yCen);
	upbound.resize(Num_xCen);

	for (int i = 0; i < Num_xCen; i++)
	{
		fin >> xCen[i];
		xCen[i] *= 1000.;
	}

	for (int i = 1; i < Num_xNode - 1; i++)xNode[i] = 0.5 * (xCen[i - 1] + xCen[i]);
	xNode[0] = xCen[0] - (xNode[1] - xCen[0]);
	xNode[Num_xNode - 1] = xCen[Num_xCen - 1] + (xCen[Num_xCen - 1] - xNode[Num_xNode - 2]);

	for (int i = 0; i < Num_yCen; i++)
	{
		fin >> yCen[i];
		yCen[i] *= 1000.;
	}

	for (int i = 1; i < Num_yNode - 1; i++)yNode[i] = 0.5 * (yCen[i - 1] + yCen[i]);
	yNode[0] = 0;
	yNode[Num_yNode - 1] = yCen[Num_yCen - 1] + (yCen[Num_yCen - 1] - yNode[Num_yNode - 2]);

	for (int i = 0; i < Num_xCen; i++)
	{
		fin >> xTopo[i];
		xTopo[i] *= 1000.;
	}
	//
	fix.resize(Num_xCen);
	for (int i = 0; i < Num_xCen; ++i) {
		fix[i].resize(Num_yCen);
	}
	//
	sgm1D.resize(Num_Cen);
	for (int i = 0; i < Num_xCen; i++)
	{
		for (int j = 0; j < Num_yCen; j++)
		{
			fin >> tmp;
			if (tmp > 9.9)
				fix[i][j] = 1;
			else if (abs(tmp - rho_water) < 0.000001 && (yCen[j] <= xTopo[i]))
				fix[i][j] = 2;
			else
				fix[i][j] = 0;
			sgm1D(j + i * Num_yCen) = -tmp;
		}
		for (int j = 0; j < Num_yCen - 1; j++)
		{
			if (fix[i][0] == 0)
			{
				upbound[i] = 0;
				break;
			}
			if (fix[i][j] == 1 && fix[i][j + 1] == 0)
			{
				upbound[i] = j + 1;
				break;
			}
		}
	}
	fin.close();

	Siteindex(data_obs);
}

void MTMesh2D::OutputMeshFile(std::string Filename)
{
	ofstream fout(Filename + ".dat");
	for (int ix = 0; ix < Num_xCen; ix++)
	{
		for (int iy = 0; iy < Num_yCen; iy++)
		{
			fout << xCen[ix] / 1000. << " " << yCen[iy] / 1000. << " " << -sgm1D(iy + ix * Num_yCen) << endl;
		}
	}
	fout.close();
	//.mesh
	string f2 = Filename + ".mesh";
	ofstream fout2(f2);
	if (marine)
		fout2 << "MARINE" << endl;
	else
		fout2 << "LAND" << endl;

	fout2 << Num_xCen << " " << Num_yCen << endl;
	for (int i = 0; i < Num_xCen; i++)
	{
		fout2 << xCen[i] * 0.001 << " ";
	}
	fout2 << endl;
	for (int i = 0; i < Num_yCen; i++)
	{
		fout2 << yCen[i] * 0.001 << " ";
	}
	fout2 << endl;
	for (int i = 0; i < Num_xCen; i++)
	{
		fout2 << xTopo[i] * 0.001 << " ";
	}
	fout2 << endl;
	for (int i = 0; i < Num_xCen; i++)
	{
		for (int j = 0; j < Num_yCen; j++)
		{
			fout2 << -sgm1D(j + i * Num_yCen) << " ";
		}
		fout2 << endl;
	}
	//gmt
	string f3 = Filename + ".gmt";
	ofstream fout3(f3);
	for (int ix = 0; ix < Num_xCen; ix++)
	{
		for (int iy = 0; iy < Num_yCen; iy++)
		{
			if (fix[ix][iy] == 0)
			{
				fout3 << "> -Z" << -sgm1D(iy + ix * Num_yCen) << endl;
				fout3 << xNode[ix] / 1000. << " " << yNode[iy] / 1000. << endl;
				fout3 << xNode[ix] / 1000. << " " << yNode[iy + 1] / 1000. << endl;
				fout3 << xNode[ix + 1] / 1000. << " " << yNode[iy + 1] / 1000. << endl;
				fout3 << xNode[ix + 1] / 1000. << " " << yNode[iy] / 1000. << endl;
			}
		}
	}
	fout3.close();
}

void MTMesh2D::AutoMesh(MTData2D data_obs, string yFilename, string topo, double value, int expand, int grid_expand, int refinement, bool site_Ref, bool Marine)
{
	if (Marine)
		marine = true;
	if (grid_expand > 7)
	{
		cerr << "Grid expansion exceed the maxmum value!" << endl;
		exit(0);
	}
	ifstream fin(yFilename);
	if (!fin) {
		std::cerr << "Can't open Depth_meshFile!" << endl;
		exit(0);
	}
	while (!fin.eof())
	{
		double yy;
		fin >> yy;
		if (fin.fail())break;
		yNode.push_back(yy);
	}
	double expand2 = expand;
	expand = expand + grid_expand;
	//expand 
	Num_xCen = data_obs.nSite + 2 * expand + refinement * (data_obs.nSite - 1);
	Num_yCen = yNode.size() - 1;
	Num_xNode = Num_xCen + 1;
	Num_yNode = Num_yCen + 1;
	Num_Cen = Num_xCen * Num_yCen;
	Num_Node = Num_xNode * Num_yNode;
	sgm1D.resize(Num_xCen * Num_yCen); xCen.resize(Num_xCen); yCen.resize(Num_yCen);	xTopo.resize(Num_xCen);
	xNode.resize(Num_xNode); yNode.resize(Num_yNode); site_index.resize(data_obs.nSite), upbound.resize(Num_xCen);
	//expand
	vector<double> xWidth_l = { 575.5, 2150.0, 4395.0, 8320.0, 16770.0, 34975.0, 74200.0, 174200.0 };
	vector<double> xWidth_r = { 575.5, 2150.0, 4395.0, 8320.0, 16770.0, 34975.0, 74200.0, 174200.0 };
	double* ref = new double[refinement * ((data_obs.nSite - 1))];
	for (int i = 0; i < data_obs.nSite - 1; i++)
	{
		for (int j = 0; j < refinement + 1; j++)
		{
			xCen[i * (refinement + 1) + j + expand] = data_obs.xSite[i] + (data_obs.xSite[i + 1] - data_obs.xSite[i]) * j / (refinement + 1);
		}
	}
	xCen[-1 + data_obs.nSite + refinement * (data_obs.nSite - 1) + expand] = data_obs.xSite[data_obs.nSite - 1];
	double xl = abs(xCen[expand] - xCen[expand + 1]);
	double xr = abs(xCen[-1 + data_obs.nSite + refinement * (data_obs.nSite - 1) + expand] - xCen[-2 + data_obs.nSite + refinement * (data_obs.nSite - 1) + expand]);
	for (int i = 0; i < xWidth_l.size(); i++)
	{
		xWidth_l[i] += xl * double(expand2);
		xWidth_r[i] += xr * double(expand2);
	}
	vector<double> sl, sr;
	for (int i = 0; i < expand2; i++)
	{
		sl.push_back((i + 1) * xl);
		sr.push_back((i + 1) * xr);
	}
	xWidth_l.insert(xWidth_l.begin(), sl.begin(), sl.end());
	xWidth_r.insert(xWidth_r.begin(), sr.begin(), sr.end());
	for (int i = 0; i < expand; i++)
	{
		xCen[i] = xCen[expand] - xWidth_l[expand - 1 - i];
	}

	for (int i = 0; i < expand; i++)xCen[i + expand + data_obs.nSite + refinement * (data_obs.nSite - 1)] =
		xCen[expand + data_obs.nSite - 1 + refinement * (data_obs.nSite - 1)] + xWidth_r[i];;

	for (int i = 0; i < Num_yCen; i++)yCen[i] = 0.5 * (yNode[i] + yNode[i + 1]);

	for (int i = 1; i < Num_xNode - 1; i++) {
		xNode[i] = 0.5 * (xCen[i - 1] + xCen[i]);
	}
	xNode[0] = xCen[0] - (xNode[1] - xCen[0]);

	xNode[Num_xNode - 1] = xCen[Num_xCen - 1] + (xCen[Num_xCen - 1] - xNode[Num_xNode - 2]);
	//
	double nx2;
	vector<double> xNode_new;
	//local grid refinement
	if (site_Ref)
	{
		nx2 = Num_xNode + 2 * sitref * data_obs.nSite;
		xNode_new.resize(nx2);
		for (int i = 0; i < Num_xNode; i++)
		{
			xNode_new[i] = xNode[i];
		}
		for (int i = 0; i < 2 * sitref * data_obs.nSite; i = i + 2 * sitref)
		{
			for (int j = 0; j < sitref; j++)
			{
				xNode_new[i + Num_xNode + j] = data_obs.xSite[int(i / (2 * sitref))] - double(j + 1.0) * disref;
			}
			for (int j = sitref; j < 2 * sitref; j++)
			{
				xNode_new[i + Num_xNode + j] = data_obs.xSite[int(i / (2 * sitref))] + double(j - sitref + 1.0) * disref;
			}
		}
		sort(xNode_new.begin(), xNode_new.end());
		//ok
		Num_xNode = nx2;
		Num_xCen = nx2 - 1;
		Num_Cen = Num_xCen * Num_yCen;
		Num_Node = Num_xNode * Num_yNode;
		sgm1D.resize(Num_xCen * Num_yCen); xCen.resize(Num_xCen); 	xTopo.resize(Num_xCen);
		xNode.resize(Num_xNode);  upbound.resize(Num_xCen);
		//
		for (int i = 0; i < Num_xNode; i++)
		{
			xNode[i] = xNode_new[i];
		}
		for (int i = 0; i < Num_xCen; i++)
		{
			xCen[i] = 0.5 * (xNode[i] + xNode[i + 1]);
		}
		//
	}
	//
	for (int i = 0; i < data_obs.nSite; i++)
	{
		site_index[i] = findCloseElements(xCen, data_obs.xSite[i]);
	}
	///add topo
	fix.resize(Num_xCen);
	for (int i = 0; i < Num_xCen; ++i) {
		fix[i].resize(Num_yCen);
	}
	//fileread
	vector<double> xtopo_tmp, ytopo_tmp;
	ifstream fint(topo);
	while (!fint.eof())
	{
		double xx1, yy1;
		fint >> xx1 >> yy1;
		xx1 *= 1000.; yy1 *= 1000.;
		if (Marine && yy1 < 0)
		{
			cerr << "Marine topography must >= 0 !" << endl;
			exit(0);
		}
		xtopo_tmp.push_back(xx1);
		ytopo_tmp.push_back(yy1);
	}
	fint.close();
	xtopo_tmp.push_back(999999999.); xtopo_tmp.insert(xtopo_tmp.begin(), -999999999.);
	double tt1 = ytopo_tmp.front(); double tt2 = ytopo_tmp.back();
	ytopo_tmp.push_back(tt2); ytopo_tmp.insert(ytopo_tmp.begin(), tt1);
	//interpolate
	for (int ix = 0; ix < Num_xCen; ix++)
	{
		xTopo[ix] = _linearinter1D(xtopo_tmp, ytopo_tmp, xCen[ix]);
	}
	//
	if (!Marine)
	{
		auto minElement = std::min_element(xTopo.begin(), xTopo.end());
		ymin = *minElement;
		for (int iy = 0; iy < Num_yNode; iy++)
		{
			yNode[iy] += ymin;
			if (iy < Num_yCen)
				yCen[iy] += ymin;
		}
	}
	else
	{
		ymin = 0;
	}
	//
	for (int i = 0; i < Num_xCen; i++)
	{
		for (int j = 0; j < Num_yCen; j++)
		{
			if (yCen[j] <= xTopo[i])
			{
				if (!Marine)
					fix[i][j] = 1;
				else
					fix[i][j] = 2;
			}
			else fix[i][j] = 0;
		}
		for (int j = 0; j < Num_yCen - 1; j++)
		{
			if (fix[i][0] == 0)
			{
				upbound[i] = 0;
				break;
			}
			if (fix[i][j] != 0 && fix[i][j + 1] == 0)
			{
				upbound[i] = j + 1;
				break;
			}
		}
	}
	///
	sgm1D.resize(Num_Cen);
	for (int i = 0; i < Num_xCen; i++)
	{
		for (int j = 0; j < Num_yCen; j++)
		{
			if (fix[i][j] == 0)
				sgm1D(j + i * Num_yCen) = -value;
			else
			{
				if (fix[i][j] == 1)
					sgm1D(j + i * Num_yCen) = -rho_air;
				else
					sgm1D(j + i * Num_yCen) = -rho_water;
			}
		}
	}

}

void MTMesh2D::Siteindex(MTData2D data_cal)
{
	site_index.resize(data_cal.nSite);
	for (int i = 0; i < data_cal.nSite; i++)
	{
		site_index[i] = findCloseElements(xCen, data_cal.xSite[i]);
	}
}

int MTMesh2D::findCloseElements(vector<double> a, double b)
{
	for (int i = 0; i < a.size(); ++i)
	{
		if (std::abs(a[i] - b) < 0.01)
		{
			return i;
		}
	}
	return 0;
}

double MTMesh2D::_linearinter1D(vector<double> x_data, vector<double> y_data, double x)
{
	if (x < x_data.front()) {
		cerr << x << " " << x_data.front() << endl;
		cerr << "Interpolation value is outside the range of known data" << endl;
		exit(1);
	}


	int i = 0;
	while (x > x_data[i + 1])
	{
		++i;
	}

	// 1D
	if (x <= x_data.back())
	{
		double x0 = x_data[i];
		double x1 = x_data[i + 1];
		double y0 = y_data[i];
		double y1 = y_data[i + 1];

		return y0 + (y1 - y0) * (x - x0) / (x1 - x0);
	}
	else
	{
		double x0 = x_data[i - 1];
		double x1 = x_data[i];
		double y0 = y_data[i - 1];
		double y1 = y_data[i];

		return y1 + (y1 - y0) * (x - x1) / (x1 - x0);
	}

}